<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ScaEE</title>
</head>
<body>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.theme.css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.js"></script>
<div id="msgExcluir">
  Deseja realmente sair?
</div>
    <div class="nav-lateral">

         <div class="header">
            <img src="imagens/logo.png" alt="logo">
            <input type="button" class="button-add-event" id="abrir-form" value="+">
            
        </div>


        <div class="button-pesquisar-pessoas">  
            <img src="imagens/team-building.png" alt="group">
            <input type="button" value="Pesquisar Pessoas">
        </div>

        <div class="rodapé">
            <div class="nome-sistema">
                <h1>Scaee</h1>
                <h6>Software de Cadastro e Armazenamento de Eventos Escolares</h6>
            </div>
        </div>
    </div>
    <div class="nav-search-config">
        <div class="logo-cps">
            <img src="imagens/Logo_cps.png" alt="logo cps" >
        </div>
        <div class="icons-search-config">
            <a href="#"><ion-icon name="person-add-outline" id="icon-sair-search"></ion-icon></a>
            <a href="#"><ion-icon name="search-outline" id="icon-sair-search"></ion-icon></a>
            <a href="#"><ion-icon name="log-out-outline" id="icon-sair-search" onclick="login()"></ion-icon></a>
        </div>
    </div>

    <form action="verifica_form.php" method="post">
    <div class="wrapper">

        <div class="titulo">

            <p>Cadastro de eventos</p>

        </div>

        <div class="titulo-evento">

            <label for="titulo-evento">Nome do evento: </label>
            <input type="text" id="titulo-evento" name="titulo">

        </div>


        <div class="radios">


            <div class="divRadiosOrg">
            <input type="radio" name="evento" class="radio-botao" id="close"> 
            <label for="close" class="label-radio">Evento Interno</label>
            </div>
            

            <div class="divRadiosOrg">
            <input type="radio" name="evento" class="radio-botao" id="open"> 
            <label for="open" class="label-radio">Evento Aberto</label>
            </div>

            <div class="divRadiosOrg">

            <input type="radio" name="evento" class="radio-botao" id="invite"> 
            <label for="invite" class="label-radio">Evento com Convidado</label>
            </div>

            <input type="hidden" id="color" name="color" value=""> 

        </div>
        

        <div class="datacao-evento">

        <div class="data-hora">

            <div class="data-box">

            <p class="data-e-hora-texto" id="necss2">Data inicial:</p>
            <p class="data-e-hora-texto" id="necss">Data Final:</p>
            

            </div>

            <div class="data-box-datas">
            
            <input type="date" name="startdate" id="data-evento">
            <input type="date" name="enddate" id="data-evento-2">
            </div>
            
        </div>

        <div class="hora-data">
            <div class="hora-box">
            <p class="hora-e-data-texto" id="necss2">Hora Inicial: </p>
            <p class="hora-e-data-texto" id="necss">Hora Final: </p>
            </div>
            
            <div class="hora-box-hora">
            <input type="time" name="startime" id="hora-evento">
            <input type="time" name="endtime" id="hora-evento2">
            </div>

        </div>
        </div>

        <div class="locais">
            <label for="locais-eventos">Locais Disponíveis: </label>

            <select name="select" id="locais-eventos">

                <option value="quadra">Quadra</option>

                <option value="quadra">Sala de Vídeo</option>

                <option value="quadra">Auditório</option>

            </select>

        </div>

        <div class="nome-professor">

            <label for="listas-locais" class="labelProfessor">Criador: </label>

            <input list="lista" class="listas-locais" name="nome">

            <datalist id="lista">
                <option value="Marcela Campos"></option>
                <option value="Claudemir Santos Pinto"></option>
                <option value="Sérgio Salum"></option>
            </datalist>
            
        </div>

        <div class="identifica">


            <div class="base-e-ano">

            <div class="flexbox-baseEducacional">
            <label for="listas-bases-educacionais">Base</label>

            <input list="lista-base" class="listas-bases-educacionais" name="base">

            <datalist id="lista-base">
                <option value="Técnica"></option>
                <option value="Comum"></option>
            </datalist>
            </div>


            <div class="flexbox-anoEducacional">
            <label for="listas-ano-locais">Ano</label>

            <input list="lista-ano" class="listas-ano-locais" name="ano">

            <datalist id="lista-ano">
                <option value="1°"></option>
                <option value="2°"></option>
                <option value="3°"></option>
            </datalist>
            </div>

            </div>

        <div class="curso-e-coordenador">

            <div class="orgClasseCursos">

                <div class="opcoesCursos">

                        <label for="listas-curso-locais">Curso</label>

                        <input list="lista-curso" class="listas-curso-locais" name="curso">

                        <datalist id="lista-curso">
                            <option value="Nutrição"></option>
                            <option value="Mecânica"></option>
                            <option value="Desenvolvimento de sistemas"></option>
                            <option value="Administração"></option>
                            <option value="Serviços Jurídicos"></option>
                        </datalist>
                </div>


                <div class="allCoordenadores">

                        <label for="listas-coord">Coord</label>

                        <input list="lista-coordenador" class="listas-coordenadores" name="coord">

                        <datalist id="lista-coordenador">
                            <option value="Cláudia"></option>
                            <option value="Sérgio"></option>
                            <option value="Denise"></option>
                            <option value="Eunice"></option>
                            <option value="Mariluz"></option>
                        </datalist>
                </div>

            </div>

        </div>
        
        <div class="descricaoFlexBox">
        <div class="desc">

            <div class="area-de-texto">
            <input type="text" name="descricao" id="text-desc" placeholder="Descrição do evento">
            </div>
            
        </div>
        
        </div>
        <div class="botoes">
            <input class="button-confirm" type="button" value="Cancelar" id="cancelar">
            <input class="button-confirm" type="submit" value="Confirmar" />
            </div> 
        </div>
        
        </form>

        <script src="main.js"></script>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>

