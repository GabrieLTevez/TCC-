<?php
    $servername = "LocalHost";
    $username = "root";
    $password = "";
    $dbname = "DBSCAEE";
    
    // Criar conexão
    //$con = new mysqli($servername, $username, $password);
    $con = new mysqli($servername, $username, $password, $dbname);

    /*
    $sql = "CREATE DATABASE DBSCAEE";
    if ($con->query($sql) === TRUE) {
        echo "Banco de dados criado com sucesso";
    } else {
        echo "Erro ao criar banco de dados: " . $con->error;
    } 
    

    // Verifique a conexão
    if ($con->connect_error) {
        die("Falha na conexão: ".$con->connect_error);
    }

    echo "Conectado com sucesso";
      */
    $sql = "CREATE TABLE usuario (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(60) NOT NULL,
        senha VARCHAR(30) NOT NULL,
        tipo ENUM('Gestão', 'Professor', 'Recepção') NOT NULL)";
           
    if ($con->query($sql) === TRUE) {
        echo "Tabela Usuarios criada com sucesso";
    } else {
        echo "Erro ao criar tabela: " . $con->error;
    } 
?>