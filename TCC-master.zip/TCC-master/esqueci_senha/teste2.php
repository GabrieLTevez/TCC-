<?php
// Conectar ao banco de dados
// ...
if (isset($_POST["submit"])) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "DBSCAEE";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    if (isset($_GET["token"])) {
        $token = $_GET["token"];

        // Verificar se o token existe no banco de dados e não expirou
        // ...

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $novaSenha = $_POST["novaSenha"];

            // Atualizar a senha do usuário no banco de dados
            // ...

            echo "Sua senha foi redefinida com sucesso!";
        }
    }}
?>
