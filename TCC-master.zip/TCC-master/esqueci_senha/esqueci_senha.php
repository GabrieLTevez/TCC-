<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../esqueci_senha/css.css">
    <title>SCAEE</title>
    <style>
        /* Estilos inline adicionados para facilitar a compreensão, você pode mover esses estilos para o seu arquivo CSS */
        .password-container {
            position: relative;
            margin-top: 10px;
        }

        .password-container button {
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body>
    

    <div class="background">
        <div class="blur"></div>
    </div> 
    <button class="buttonteste" id="buttonLogin" type="button" onclick="buttonLogin()">
        <img class="img1" src="../esqueci_senha/imagens/seta.png">
    </button>    
    <div class="logo">
        <div class="img">
            <img src="../esqueci_senha/imagens/logo.png">
        </div>
    </div>

    <div class="login-card">
        <div class="text1">
            <h1>
                Esqueci minha senha
            </h1>
            <span>Para sua segurança enviaremos um código para validar sua redefinição de senha.</span>
        
        </div>
        <form class="login-form" method="POST" action="esqueci_senha.php">

            <input type="text" name="email" placeholder="E-mail">

            <button type="submit">ENVIAR</button>
            
        </form>
    </div>
</body>
    <script src="../esqueci_senha/java.js"></script>
</html>

