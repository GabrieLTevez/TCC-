function buttonLogin() {
    window.location.href = "http://localhost/TCC_ETEC/login.php";
}