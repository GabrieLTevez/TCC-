<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../esqueci_senha/recupera.css">
    <title>SCAEE</title>
    <style>
        /* Estilos inline adicionados para facilitar a compreensão, você pode mover esses estilos para o seu arquivo CSS */
        .password-container {
            position: relative;
            margin-top: 10px;
        }

        .password-container button {
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body>
    <div class="background">
        <div class="blur"></div>
    </div> 
    <div class="logo">
        <div class="img">
            <img src="../esqueci_senha/imagens/logo.png">
        </div>
    </div>
    <button class="buttonteste" type="button" onclick="">
        <img class="img1" src="../esqueci_senha/imagens/seta.png">
    </button>    

    <div class="login-card">
        <div class="text1">
            <h1>
                Digite sua nova senha.
            </h1>

        
        </div>
        <form class="login-form">
            <div class="password-container">
                <input type="password" id="passwordInput1" placeholder="Senha">
                <button id="toggleButton1" type="button" onclick="togglePasswordVisibility1()">
                    <img src="../esqueci_senha/imagens/olho.png" alt="Mostrar Senha">
                </button>
            </div> 

            <div class="password-container">
                <input type="password" id="passwordInput" placeholder="Rescreva a Senha">
                <button id="toggleButton" type="button" onclick="togglePasswordVisibility()">
                    <img src="../esqueci_senha/imagens/olho.png" alt="Mostrar Senha">
                </button>
            </div>  

            <button class="pfv" type="submit">ENVIAR</button>
            
        </form>
    </div>
</body>
    <script src="../esqueci_senha/java2.js"></script>
</html>