<?php
$para = 'joaogabrieltevez01@gmail.com';
$assunto = 'Assunto do e-mail';
$mensagem = 'Corpo do e-mail';

$headers = 'De: joaogabrieltevez02@gmail.com' . "\r\n" .
    'Reply-To: joaogabrieltevez02@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Envia o e-mail
if (mail($para, $assunto, $mensagem, $headers)) {
    echo 'E-mail enviado com sucesso!';
} else {
    echo 'Erro ao enviar o e-mail.';
}
?>
